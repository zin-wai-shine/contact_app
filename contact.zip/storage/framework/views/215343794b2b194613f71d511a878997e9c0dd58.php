<?php $__env->startSection('content'); ?>
    <div class="mtContact px-5">
       <table class="table table-hover">
           <thead>
               <tr>
                   <th>From</th>
                   <th>To</th>
                   <th>contact</th>
                   <th>dates : times</th>
                   <th></th>
               </tr>
           </thead>

           <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $sends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $send): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                           <tr class="align-middle">
                               <td><?php echo e($send->from); ?></td>
                               <td><?php echo e($send->to); ?></td>
                               <td>new contact . . . .</td>
                               <td><?php echo e($send->created_at->format('d M Y')); ?></td>
                               <td>
                                   <div class="d-flex align-items-center gap-2">
                                       <a href="<?php echo e(route('send.show', $send->id)); ?>" class="btn btn-secondary"><i class="fa fa-info-circle"></i></a>
                                       <form action="<?php echo e(route('recieve')); ?>" method="post">
                                           <?php echo csrf_field(); ?>
                                           <input type="number" name="contact_id" value="<?php echo e($send->contact_id); ?>" hidden>
                                           <input type="number" name="send_id" value="<?php echo e($send->id); ?>" hidden>
                                           <button class="btn btn-primary"><i class="fa fa-inbox"></i></button>
                                       </form>

                                       <form action="<?php echo e(route('send.destroy', $send->id)); ?>" method="POST">
                                           <?php echo csrf_field(); ?>
                                           <?php echo method_field('delete'); ?>
                                           <button class="btn btn-danger"><i class="fa fa-trash-can"></i></button>
                                       </form>

                                   </div>
                               </td>
                           </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <?php endif; ?>
           </tbody>
       </table>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zinwaishine/Desktop/contact-app/laravel/resources/views/inbox/index.blade.php ENDPATH**/ ?>