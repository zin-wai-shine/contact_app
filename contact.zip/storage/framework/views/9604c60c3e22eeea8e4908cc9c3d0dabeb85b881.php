<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body>

<?php if(auth()->guard()->guest()): ?>
    <div class="d-flex align-items-center justify-content-between gap-5 p-2">
        <div class="d-flex align-items-center gap-3">
            <div class="d-flex align-items-center gap-2">
                <div class="bg-primary rounded-circle item__photo d-flex justify-content-center align-items-center">
                    <i class="fa fa-user text-light"></i>
                </div>
                <h5 class="mb-0 text-secondary fw-light">Contacts</h5>
            </div>
        </div>

      <div class="d-flex align-items-center justify-content-center gap-2">
          <?php if(\Illuminate\Support\Facades\Route::has('login')): ?>
              <a class=" btn btn-primary" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
          <?php endif; ?>
          <?php if(\Illuminate\Support\Facades\Route::has('register')): ?>
              <a class=" btn btn-primary" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
          <?php endif; ?>
      </div>


    </div>

    <div class="p-2 w-100">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
<?php else: ?>
    <?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="d-flex">
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="p-2 w-100">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
<?php endif; ?>

<?php echo $__env->yieldPushContent('script'); ?>

</body>
</html>
<?php /**PATH /home/zinwaishine/Desktop/contact-app/laravel/resources/views/layouts/app.blade.php ENDPATH**/ ?>