<?php $__env->startSection('content'); ?>

    <div class="w-50 px-5 mtContact">
        <div class="w-100">
            
            <div class="d-flex gap-5 align-items-end" >
                <div class="d-flex gap-5 align-items-center">
                    <div class="upload__photo__container" style="background-image:url(
                    <?php echo e($contact->featured_img == null ? asset('profile/profile.png') : asset(Storage::url($contact->featured_img))); ?>

                        )">
                    </div>
                    <div>
                        <h6>From : <?php echo e($send->from); ?></h6>
                        <h6>To : <?php echo e($send->to); ?></h6>
                        <h6>Name : <?php echo e($contact->first_name); ?> <?php echo e($contact->last_name); ?></h6>
                        <?php if($contact->email != null): ?>
                            <h6>Email : <?php echo e($contact->email); ?></h6>
                        <?php endif; ?>
                        <h6>Phone : <?php echo e($contact->phone); ?></h6>
                    </div>
                </div>

                <div>
                    <a href="<?php echo e(route('send.index')); ?>">
                        <button class="btn btn-secondary px-3 btn-sm "><i class="fa fa-arrow-left"></i></button>
                    </a>
                </div>
            </div>
        </div>
        <hr>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zinwaishine/Desktop/contact-app/contact/resources/views/inbox/show.blade.php ENDPATH**/ ?>